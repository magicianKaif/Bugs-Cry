import React, { useState } from 'react';
import Card from '../components/Card';
import Button from '../components/Button';

/**
 * Screen 1 — Upload Evidence
 * Accepts screenshots/images, raw HTTP request/response text, and code snippets.
 * Includes redaction notice: evidence is sent to third-party LLM APIs.
 */
export default function UploadEvidence({ onSubmit }) {
  const [tab, setTab] = useState('image');
  const [text, setText] = useState('');
  const [redact, setRedact] = useState(true);

  const tabs = [
    { key: 'image', label: 'Screenshot / Image', hint: 'PNG or JPG from manual testing or scanner output. Regions of interest are detected automatically.' },
    { key: 'http', label: 'HTTP Request/Response', hint: 'Paste the raw request and response pair, e.g. from Burp Suite or OWASP ZAP.' },
    { key: 'code', label: 'Code Snippet', hint: 'Paste the flagged code with at least 5 lines of surrounding context.' },
  ];

  return (
    <main style={{ maxWidth: 960, margin: '0 auto', padding: 'var(--space-6)' }}>
      <h1 style={{ font: 'var(--text-heading-2)', color: 'var(--text-primary)' }}>Upload Evidence</h1>
      <p style={{ font: 'var(--text-body)', color: 'var(--text-secondary)', maxWidth: 640 }}>
        Submit raw evidence for validation. Every downstream claim in the report will cite this material — nothing enters the pipeline without a traceable source.
      </p>

      <div role="tablist" aria-label="Evidence type" style={{ display: 'flex', gap: 'var(--space-2)', margin: 'var(--space-6) 0 var(--space-4)', flexWrap: 'wrap' }}>
        {tabs.map((t) => (
          <button key={t.key} role="tab" aria-selected={tab === t.key} onClick={() => setTab(t.key)}
            style={{ padding: '8px 16px', borderRadius: 'var(--radius-pill)', border: '1px solid var(--border-default)', cursor: 'pointer', font: 'var(--text-body-sm)', fontWeight: 600,
              background: tab === t.key ? 'var(--color-accent-500)' : 'transparent', color: tab === t.key ? 'var(--text-on-accent)' : 'var(--text-body)' }}>
            {t.label}
          </button>
        ))}
      </div>

      <Card>
        {tab === 'image' ? (
          <label htmlFor="file-drop" style={{ display: 'grid', placeItems: 'center', gap: 'var(--space-3)', minHeight: 220, border: '2px dashed var(--border-default)', borderRadius: 'var(--radius-medium)', cursor: 'pointer', color: 'var(--text-secondary)', font: 'var(--text-body)' }}>
            <span>Drop an image here, or browse</span>
            <input id="file-drop" type="file" accept="image/png,image/jpeg" style={{ position: 'absolute', width: 1, height: 1, overflow: 'hidden', clip: 'rect(0 0 0 0)' }} />
          </label>
        ) : (
          <>
            <label htmlFor="evidence-text" style={{ font: 'var(--text-body-sm)', color: 'var(--text-secondary)' }}>{tabs.find(t => t.key === tab).hint}</label>
            <textarea id="evidence-text" value={text} onChange={(e) => setText(e.target.value)} rows={12}
              placeholder={tab === 'http' ? 'POST /api/login HTTP/1.1\nHost: example.com\n…' : 'function renderBio(bio) {\n  …\n}'}
              style={{ width: '100%', marginTop: 'var(--space-3)', font: 'var(--text-mono)', color: 'var(--text-body)', background: 'var(--color-neutral-900)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-medium)', padding: 'var(--space-4)', resize: 'vertical' }} />
          </>
        )}

        <label style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)', marginTop: 'var(--space-4)', font: 'var(--text-body-sm)', color: 'var(--text-body)', cursor: 'pointer' }}>
          <input type="checkbox" checked={redact} onChange={(e) => setRedact(e.target.checked)} />
          Redact cookies, tokens, and credentials before upload
          <span title="Sensitive fields are masked locally before evidence leaves your environment.">ⓘ</span>
        </label>

        <p role="note" style={{ font: 'var(--text-caption)', color: 'var(--color-warning-500)', marginTop: 'var(--space-3)' }}>
          Privacy notice: evidence is sent to third-party APIs (Google Gemini, OpenAI, Anthropic). Do not upload data covered by disclosure restrictions.
        </p>

        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 'var(--space-4)' }}>
          <Button variant="primary" onClick={() => onSubmit?.({ type: tab, text, redact })}>Extract Evidence →</Button>
        </div>
      </Card>
    </main>
  );
}
