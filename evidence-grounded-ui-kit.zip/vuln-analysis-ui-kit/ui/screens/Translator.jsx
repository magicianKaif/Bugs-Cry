import React from 'react';
import Card from '../components/Card';

/**
 * Screen 4 — ChatGPT Translation (Translator)
 * Dual-track output: executive summary (plain language) +
 * developer remediation track with code examples.
 */
export default function Translator({ result = DEMO }) {
  return (
    <main style={{ maxWidth: 1100, margin: '0 auto', padding: 'var(--space-6)' }}>
      <h1 style={{ font: 'var(--text-heading-2)', color: 'var(--text-primary)' }}>ChatGPT Translation</h1>
      <p style={{ font: 'var(--text-body)', color: 'var(--text-secondary)' }}>
        One validated finding, two audiences. The executive track explains business impact; the developer track provides remediation.
      </p>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: 'var(--space-6)', marginTop: 'var(--space-6)' }}>
        <Card title="Executive Summary" style={{ borderTop: '3px solid var(--color-accent-500)' }}>
          <p style={{ font: 'var(--text-body)', color: 'var(--text-body)' }}>{result.executiveSummary}</p>
          <dl style={{ font: 'var(--text-body-sm)', display: 'grid', gridTemplateColumns: '140px 1fr', gap: 'var(--space-2)' }}>
            <dt style={{ color: 'var(--text-secondary)' }}>Business risk</dt><dd style={{ margin: 0, color: 'var(--text-body)' }}>{result.businessRisk}</dd>
            <dt style={{ color: 'var(--text-secondary)' }}>Suggested priority</dt><dd style={{ margin: 0, color: 'var(--text-body)' }}>{result.priority}</dd>
          </dl>
        </Card>

        <Card title="Developer Remediation" style={{ borderTop: '3px solid var(--color-teal-500)' }}>
          <ol style={{ font: 'var(--text-body-sm)', color: 'var(--text-body)', paddingLeft: 'var(--space-4)', margin: 0 }}>
            {result.remediationSteps.map((s, i) => <li key={i} style={{ marginBottom: 'var(--space-2)' }}>{s}</li>)}
          </ol>
          <figure style={{ margin: 'var(--space-4) 0 0' }}>
            <figcaption style={{ font: 'var(--text-caption)', color: 'var(--text-secondary)', marginBottom: 'var(--space-2)' }}>Patched code example</figcaption>
            <pre style={{ font: 'var(--text-mono)', color: 'var(--text-body)', background: 'var(--color-neutral-900)', padding: 'var(--space-4)', borderRadius: 'var(--radius-medium)', overflow: 'auto' }}>
              <code>{result.codeExample}</code>
            </pre>
          </figure>
        </Card>
      </div>
    </main>
  );
}

const DEMO = {
  executiveSummary: 'An attacker can view the full customer user list without logging in. This exposes names and email addresses, creating phishing risk and regulatory exposure. The issue is confirmed and reproducible.',
  businessRisk: 'Customer data exposure; potential GDPR Article 32 finding.',
  priority: 'Fix within 7 days (Critical).',
  remediationSteps: [
    'Add an authorization check requiring the admin role on GET /admin/users.',
    'Return 403 for non-admin principals; log the attempt.',
    'Add a regression test asserting 403 for anonymous requests.',
  ],
  codeExample: `@app.get("/admin/users")
@require_role("admin")   # enforce authorization
def list_users():
    return jsonify(User.query.all())`,
};
