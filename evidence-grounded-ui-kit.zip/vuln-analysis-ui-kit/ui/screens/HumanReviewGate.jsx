import React, { useState } from 'react';
import Table from '../components/Table';
import Modal from '../components/Modal';
import { ConfidenceMeter } from './GeminiAnalysis';
import findings from '../fixtures/findings.json';

/**
 * Screen 6 — Human Review Gate
 * Lists findings with confidence < 70 and cross-model disagreements.
 * Reviewer can Approve / Modify / Reject each item.
 */
export default function HumanReviewGate({ items = findings }) {
  const queue = items.filter((f) => f.confidence < 70 || f.flags.includes('cross_model_disagreement'));
  const [active, setActive] = useState(null);
  const [decisions, setDecisions] = useState({});

  const decide = (id, d) => { setDecisions({ ...decisions, [id]: d }); setActive(null); };

  const columns = [
    { key: 'id', label: 'ID', sortable: true },
    { key: 'title', label: 'Finding', sortable: true },
    { key: 'severity', label: 'Severity', sortable: true },
    { key: 'confidence', label: 'Confidence', sortable: true },
    { key: 'reason', label: 'Flag reason' },
    { key: 'status', label: 'Decision' },
  ];
  const rows = queue.map((f) => ({
    ...f,
    reason: [
      f.confidence < 70 && `Low confidence (${f.confidence}%)`,
      f.flags.includes('cross_model_disagreement') && 'Model disagreement',
    ].filter(Boolean).join(' · '),
    status: decisions[f.id] || 'Pending',
  }));

  return (
    <main style={{ maxWidth: 1200, margin: '0 auto', padding: 'var(--space-6)' }}>
      <h1 style={{ font: 'var(--text-heading-2)', color: 'var(--text-primary)' }}>Human Review Gate</h1>
      <p style={{ font: 'var(--text-body)', color: 'var(--text-secondary)', maxWidth: 720 }}>
        {queue.length} findings require judgment before they enter the report.
        Approve items you agree with, Modify to adjust severity or wording, Reject to remove them.
        Reviewer guidance: check the cited evidence first; if the raw input does not support the claim, reject.
      </p>

      <Table columns={columns} rows={rows} onRowAction={setActive} caption="Findings queued for human review" />

      <Modal
        open={!!active}
        title={active ? `Review ${active.id}: ${active.title}` : ''}
        onClose={() => setActive(null)}
        onApprove={() => decide(active.id, 'Approved')}
        onModify={() => decide(active.id, 'Modified')}
        onReject={() => decide(active.id, 'Rejected')}
      >
        {active && (
          <>
            <ConfidenceMeter value={active.confidence} />
            <dl style={{ font: 'var(--text-body-sm)', display: 'grid', gridTemplateColumns: '120px 1fr', gap: 'var(--space-2)', marginTop: 'var(--space-4)' }}>
              <dt style={{ color: 'var(--text-secondary)' }}>CWE</dt><dd style={{ margin: 0 }}>{active.cwe}</dd>
              <dt style={{ color: 'var(--text-secondary)' }}>OWASP</dt><dd style={{ margin: 0 }}>{active.owasp}</dd>
              <dt style={{ color: 'var(--text-secondary)' }}>CVSS</dt><dd style={{ margin: 0, font: 'var(--text-mono)' }}>{active.cvss}</dd>
            </dl>
          </>
        )}
      </Modal>
    </main>
  );
}
