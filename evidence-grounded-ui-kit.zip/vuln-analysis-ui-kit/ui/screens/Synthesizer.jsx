import React from 'react';
import Card from '../components/Card';

/**
 * Screen 5 — Claude Synthesis (Synthesizer)
 * Assembled report structure with cross-model coherence checks
 * and flagged contradictions between Analyst and Translator output.
 */
export default function Synthesizer({ result = DEMO }) {
  return (
    <main style={{ maxWidth: 1100, margin: '0 auto', padding: 'var(--space-6)' }}>
      <h1 style={{ font: 'var(--text-heading-2)', color: 'var(--text-primary)' }}>Claude Synthesis</h1>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: 'var(--space-6)', marginTop: 'var(--space-6)' }}>
        <Card title="Assembled Report Structure">
          <ol style={{ font: 'var(--text-body-sm)', color: 'var(--text-body)', paddingLeft: 'var(--space-4)', margin: 0 }}>
            {result.structure.map((s, i) => (
              <li key={i} style={{ marginBottom: 'var(--space-2)' }}>
                <strong style={{ color: 'var(--text-primary)' }}>{s.section}</strong>
                <span style={{ color: 'var(--text-secondary)' }}> — {s.detail}</span>
              </li>
            ))}
          </ol>
        </Card>

        <Card title="Flagged Contradictions" style={{ borderTop: '3px solid var(--color-warning-500)' }}>
          {result.contradictions.length === 0 ? (
            <p style={{ font: 'var(--text-body)', color: 'var(--color-success-500)' }}>No contradictions detected across model outputs.</p>
          ) : (
            <ul style={{ margin: 0, paddingLeft: 'var(--space-4)' }}>
              {result.contradictions.map((c, i) => (
                <li key={i} style={{ font: 'var(--text-body-sm)', color: 'var(--text-body)', marginBottom: 'var(--space-3)' }}>
                  <strong style={{ color: 'var(--color-warning-500)' }}>{c.field}</strong>: {c.description}
                  <br /><span style={{ color: 'var(--text-secondary)' }}>Analyst: {c.analyst} · Translator: {c.translator}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </main>
  );
}

const DEMO = {
  structure: [
    { section: 'Executive Summary', detail: 'risk framing, 3 Critical findings, remediation timeline' },
    { section: 'Scope & Methodology', detail: 'targets, evidence types, pipeline stages' },
    { section: 'Findings', detail: '10 items, interleaved executive + developer tracks' },
    { section: 'Risk Ratings', detail: 'CVSS 3.1 vectors with Analyst justifications' },
    { section: 'Remediation Plan', detail: 'prioritized developer track, owners TBD' },
    { section: 'Appendices', detail: 'raw evidence references, tool versions' },
  ],
  contradictions: [
    {
      field: 'FND-005 severity',
      description: 'Analyst rates Low, Translator executive copy implies Medium business urgency.',
      analyst: 'Low (CVSS 3.7)', translator: '"notable exposure"',
    },
    {
      field: 'FND-007 verdict',
      description: 'Analyst is uncertain (58%); Translator drafted remediation as if confirmed.',
      analyst: 'Uncertain', translator: '"attacker can forge tokens"',
    },
  ],
};
