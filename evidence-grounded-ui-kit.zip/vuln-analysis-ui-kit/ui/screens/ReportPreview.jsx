import React from 'react';
import Card from '../components/Card';
import Button from '../components/Button';
import Badge from '../components/Badge';
import findings from '../fixtures/findings.json';

/**
 * Screen 7 — Report Preview
 * Renders the final DOCX layout with executive and developer tracks
 * interleaved per finding, plus a downloadable DOCX mock.
 */
export default function ReportPreview({ items = findings, onExport }) {
  const approved = items.filter((f) => f.verdict === 'true_positive');
  return (
    <main style={{ maxWidth: 960, margin: '0 auto', padding: 'var(--space-6)' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 'var(--space-4)' }}>
        <h1 style={{ font: 'var(--text-heading-2)', color: 'var(--text-primary)', margin: 0 }}>Report Preview</h1>
        <Button variant="primary" onClick={onExport}>Download DOCX</Button>
      </header>

      {/* Paper-like preview of the DOCX layout */}
      <article style={{ background: 'var(--color-neutral-0)', color: '#11161D', borderRadius: 'var(--radius-large)', padding: 'var(--space-12)', marginTop: 'var(--space-6)', boxShadow: 'var(--shadow-elevated)' }}>
        <h2 style={{ font: 'var(--text-heading-2)', marginTop: 0 }}>Security Assessment Report</h2>
        <p style={{ color: '#3C4653' }}>Evidence-Grounded Multi-Agent Analysis · {approved.length} confirmed findings</p>

        <h3>1. Executive Summary</h3>
        <p>Assessment identified {approved.length} validated vulnerabilities, including {approved.filter(f => f.severity === 'Critical').length} critical issues requiring action within 7 days. All findings are substantiated by raw evidence cited in the appendices.</p>

        <h3>2. Findings (executive + developer tracks)</h3>
        {approved.slice(0, 3).map((f) => (
          <section key={f.id} style={{ borderLeft: `4px solid ${SEV[f.severity]}`, paddingLeft: 16, marginBottom: 24 }}>
            <h4 style={{ margin: '0 0 4px' }}>{f.id}: {f.title} <Badge severity={f.severity} /></h4>
            <p style={{ margin: '4px 0' }}><em>For leadership:</em> {EXEC[f.severity]}</p>
            <p style={{ margin: '4px 0', fontFamily: 'monospace', fontSize: 14 }}><strong>For engineering:</strong> {f.cwe} · {f.cvss}</p>
          </section>
        ))}
        <p style={{ color: '#3C4653' }}>… {approved.length - 3} additional findings, plus Scope, Methodology, Risk Ratings, Remediation Plan, and Appendices.</p>
      </article>

      <Card title="Export" style={{ marginTop: 'var(--space-6)' }}>
        <p style={{ font: 'var(--text-body-sm)', color: 'var(--text-secondary)' }}>
          Exports a styled DOCX with placeholders filled from pipeline output. See docs/DOCX-template.docx for the template.
        </p>
      </Card>
    </main>
  );
}

const SEV = { Critical: '#EF4444', High: '#F59E0B', Medium: '#EAB308', Low: '#22C55E' };
const EXEC = {
  Critical: 'Immediate action required; material risk to customer data.',
  High: 'Prompt remediation advised; meaningful exposure.',
  Medium: 'Schedule within the current sprint.',
  Low: 'Track as hygiene improvement.',
};
