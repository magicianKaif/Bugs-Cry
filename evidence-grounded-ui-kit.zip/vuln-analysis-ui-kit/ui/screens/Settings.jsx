import React, { useState } from 'react';
import Card from '../components/Card';
import Button from '../components/Button';

/**
 * Screen 8 — Settings
 * API keys (stored server-side as environment variables; the UI never
 * persists them), model selection per pipeline role, and thresholds.
 */
export default function Settings({ onSave }) {
  const [cfg, setCfg] = useState({
    analystModel: 'gemini-2.5-pro',
    translatorModel: 'gpt-5',
    synthesizerModel: 'claude-sonnet-4-5',
    confidenceThreshold: 70,
  });
  const set = (k) => (e) => setCfg({ ...cfg, [k]: e.target.value });

  const Field = ({ label, hint, children }) => (
    <div style={{ marginBottom: 'var(--space-4)' }}>
      <label style={{ display: 'block', font: 'var(--text-body-sm)', fontWeight: 600, color: 'var(--text-body)', marginBottom: 'var(--space-2)' }}>{label}</label>
      {children}
      {hint && <p style={{ font: 'var(--text-caption)', color: 'var(--text-secondary)', margin: 'var(--space-1) 0 0' }}>{hint}</p>}
    </div>
  );
  const inputStyle = { width: '100%', font: 'var(--text-body-sm)', color: 'var(--text-body)', background: 'var(--color-neutral-900)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-medium)', padding: '10px 12px' };

  return (
    <main style={{ maxWidth: 760, margin: '0 auto', padding: 'var(--space-6)' }}>
      <h1 style={{ font: 'var(--text-heading-2)', color: 'var(--text-primary)' }}>Settings</h1>

      <Card title="API Keys" style={{ marginTop: 'var(--space-6)' }}>
        <p role="note" style={{ font: 'var(--text-caption)', color: 'var(--color-warning-500)', marginTop: 0 }}>
          Keys are stored only as server-side environment variables (GEMINI_API_KEY, OPENAI_API_KEY, ANTHROPIC_API_KEY). This UI submits them over TLS to the orchestration service and never writes them to disk or localStorage.
        </p>
        <Field label="Google Gemini API key"><input type="password" placeholder="••••••••" autoComplete="off" style={inputStyle} /></Field>
        <Field label="OpenAI API key"><input type="password" placeholder="••••••••" autoComplete="off" style={inputStyle} /></Field>
        <Field label="Anthropic API key"><input type="password" placeholder="••••••••" autoComplete="off" style={inputStyle} /></Field>
      </Card>

      <Card title="Model Selection" style={{ marginTop: 'var(--space-6)' }}>
        <Field label="Analyst (evidence interpretation)" hint="Role per framework: Gemini">
          <select value={cfg.analystModel} onChange={set('analystModel')} style={inputStyle}>
            <option>gemini-2.5-pro</option><option>gemini-2.5-flash</option>
          </select>
        </Field>
        <Field label="Translator (dual-audience copy)" hint="Role per framework: ChatGPT">
          <select value={cfg.translatorModel} onChange={set('translatorModel')} style={inputStyle}>
            <option>gpt-5</option><option>gpt-5-mini</option>
          </select>
        </Field>
        <Field label="Synthesizer (report assembly)" hint="Role per framework: Claude">
          <select value={cfg.synthesizerModel} onChange={set('synthesizerModel')} style={inputStyle}>
            <option>claude-sonnet-4-5</option><option>claude-opus-4-1</option>
          </select>
        </Field>
      </Card>

      <Card title="Thresholds" style={{ marginTop: 'var(--space-6)' }}>
        <Field label="Human-review confidence threshold" hint="Findings below this score are routed to the Review Gate (default 70).">
          <input type="number" min="0" max="100" value={cfg.confidenceThreshold} onChange={set('confidenceThreshold')} style={{ ...inputStyle, width: 120 }} />
        </Field>
      </Card>

      <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 'var(--space-6)' }}>
        <Button variant="primary" onClick={() => onSave?.(cfg)}>Save settings</Button>
      </div>
    </main>
  );
}
