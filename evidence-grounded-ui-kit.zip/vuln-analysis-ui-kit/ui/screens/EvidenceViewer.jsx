import React from 'react';
import { EvidenceCard } from '../components/Card';

/**
 * Screen 2 — Evidence Viewer
 * Shows raw input alongside the normalized evidence object
 * (method, headers, params, response code, code context, image region).
 */
export default function EvidenceViewer({ evidence = DEMO }) {
  return (
    <main style={{ maxWidth: 1100, margin: '0 auto', padding: 'var(--space-6)' }}>
      <h1 style={{ font: 'var(--text-heading-2)', color: 'var(--text-primary)' }}>Evidence Viewer</h1>
      <p style={{ font: 'var(--text-body)', color: 'var(--text-secondary)' }}>
        Normalized evidence object <code style={{ font: 'var(--text-mono)', color: 'var(--color-teal-500)' }}>{evidence.id}</code> — persists through the pipeline; toggle to inspect raw input.
      </p>
      <EvidenceCard evidence={evidence} />
    </main>
  );
}

const DEMO = {
  id: 'EV-0042',
  title: 'POST /api/login — response pair',
  method: 'POST',
  path: '/api/login',
  responseCode: 200,
  codeContext: 'auth.py:57 — query = f"SELECT * FROM users WHERE email=\'{email}\'"',
  imageRegion: null,
  raw: `POST /api/login HTTP/1.1
Host: target.example.com
Content-Type: application/json

{"email":"admin' OR '1'='1","password":"x"}

HTTP/1.1 200 OK
Set-Cookie: session=eyJhbGciOi…

{"token":"eyJhbGciOiJIUzI1NiIs…","role":"admin"}`,
  citations: [
    { snippet: "' OR '1'='1", source: 'request body, param "email"' },
    { snippet: '"role":"admin"', source: 'response body, line 3' },
  ],
};
