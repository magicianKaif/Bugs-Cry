import React from 'react';
import Card from '../components/Card';
import Badge from '../components/Badge';

/**
 * Screen 3 — Gemini Analysis (Analyst)
 * Validity verdict, confidence meter, inline evidence citations,
 * CWE/OWASP mapping, CVSS vector with justification.
 */
export default function GeminiAnalysis({ result = DEMO }) {
  return (
    <main style={{ maxWidth: 1100, margin: '0 auto', padding: 'var(--space-6)' }}>
      <header style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4)', flexWrap: 'wrap' }}>
        <h1 style={{ font: 'var(--text-heading-2)', color: 'var(--text-primary)', margin: 0 }}>Gemini Analysis</h1>
        <Badge severity={result.severity} />
        <VerdictPill verdict={result.verdict} />
      </header>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 'var(--space-6)', marginTop: 'var(--space-6)' }}>
        <Card title="Validity & Confidence">
          <ConfidenceMeter value={result.confidence} />
          <p style={{ font: 'var(--text-body-sm)', color: 'var(--text-secondary)' }}>
            {result.confidence < 70
              ? 'Below the 70% gate — this finding is queued for human review.'
              : 'Above the 70% gate — eligible for automatic pipeline progression.'}
          </p>
        </Card>

        <Card title="Classification">
          <dl style={{ display: 'grid', gridTemplateColumns: '120px 1fr', gap: 'var(--space-2) var(--space-4)', margin: 0, font: 'var(--text-body-sm)' }}>
            <dt style={{ color: 'var(--text-secondary)' }}>CWE <span title="Common Weakness Enumeration — a community catalog of software weakness types.">ⓘ</span></dt>
            <dd style={{ margin: 0, color: 'var(--text-body)' }}>{result.cwe} — {result.cweName}</dd>
            <dt style={{ color: 'var(--text-secondary)' }}>OWASP</dt>
            <dd style={{ margin: 0, color: 'var(--text-body)' }}>{result.owasp}</dd>
          </dl>
        </Card>

        <Card title="CVSS Vector" style={{ gridColumn: '1 / -1' }}>
          <code style={{ font: 'var(--text-mono)', color: 'var(--color-teal-500)', wordBreak: 'break-all' }}>{result.cvss}</code>
          <span title="Common Vulnerability Scoring System — industry standard for rating severity (0.0–10.0)." style={{ color: 'var(--text-secondary)' }}> ⓘ</span>
          <p style={{ font: 'var(--text-body-sm)', color: 'var(--text-secondary)' }}>{result.cvssJustification}</p>
        </Card>

        <Card title="Cited Evidence" style={{ gridColumn: '1 / -1' }}>
          <ul style={{ margin: 0, paddingLeft: 'var(--space-4)' }}>
            {result.citations.map((c, i) => (
              <li key={i} style={{ font: 'var(--text-body-sm)', color: 'var(--text-body)', marginBottom: 'var(--space-2)' }}>
                <q style={{ color: 'var(--color-primary-100)' }}>{c.snippet}</q> — {c.source}
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </main>
  );
}

function VerdictPill({ verdict }) {
  const map = { true_positive: ['True positive', 'var(--color-success-500)'], false_positive: ['False positive', 'var(--color-neutral-500)'], uncertain: ['Uncertain', 'var(--color-warning-500)'], informational: ['Informational', 'var(--color-info-500)'] };
  const [label, color] = map[verdict] || map.uncertain;
  return <span style={{ font: 'var(--text-caption)', fontWeight: 700, color: 'var(--color-primary-900)', background: color, borderRadius: 'var(--radius-pill)', padding: '2px 12px' }}>{label}</span>;
}

export function ConfidenceMeter({ value }) {
  const color = value < 70 ? 'var(--color-warning-500)' : 'var(--color-success-500)';
  return (
    <div role="meter" aria-valuenow={value} aria-valuemin={0} aria-valuemax={100} aria-label={`Confidence ${value} percent`}>
      <div style={{ display: 'flex', justifyContent: 'space-between', font: 'var(--text-caption)', color: 'var(--text-secondary)' }}>
        <span>Confidence</span><strong style={{ color }}>{value}%</strong>
      </div>
      <div style={{ height: 8, borderRadius: 'var(--radius-pill)', background: 'var(--color-neutral-700)', marginTop: 'var(--space-2)' }}>
        <div style={{ width: `${value}%`, height: '100%', borderRadius: 'var(--radius-pill)', background: color, transition: 'width var(--motion-normal) var(--motion-ease)' }} />
      </div>
      <div style={{ height: 2, width: 2, background: 'var(--text-primary)', position: 'relative', left: '70%', marginTop: -10 }} aria-hidden="true" />
    </div>
  );
}

const DEMO = {
  severity: 'Critical',
  verdict: 'true_positive',
  confidence: 91,
  cwe: 'CWE-862', cweName: 'Missing Authorization',
  owasp: 'A01:2021 Broken Access Control',
  cvss: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N',
  cvssJustification: 'Unauthenticated network access to a full user list: high confidentiality and integrity impact, no availability impact observed.',
  citations: [
    { snippet: 'GET /admin/users → 200 OK', source: 'HTTP pair EV-0042, response line 1' },
    { snippet: '"email":"admin@target.example.com"', source: 'Response body, row 1' },
    { snippet: 'No authorization middleware on route', source: 'Code context routes.py:112' },
  ],
};
