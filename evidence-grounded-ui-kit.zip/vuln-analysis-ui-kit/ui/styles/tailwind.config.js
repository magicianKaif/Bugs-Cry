/** @type {import('tailwindcss').Config} */
/* Optional Tailwind mapping of design-system.tokens.json.
   If you don't use Tailwind, ui/styles/tokens.css alone is sufficient. */
module.exports = {
  content: ['./ui/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: { 900: '#0F1B2D', 800: '#16263C', 700: '#1E3250', 600: '#2A3B52', 100: '#D6E4F5' },
        neutral: { 900: '#11161D', 700: '#3C4653', 500: '#6B7787', 400: '#9AA7B8', 100: '#E7ECF2', 0: '#F4F6F9' },
        accent: { 500: '#F97316', 600: '#D9630E' },
        teal: { 500: '#14B8A6' },
        danger: { 500: '#EF4444', 100: '#FCA5A5' },
        warning: { 500: '#F59E0B' },
        success: { 500: '#22C55E' },
        info: { 500: '#3B82F6' },
        severity: { critical: '#EF4444', high: '#F59E0B', medium: '#EAB308', low: '#22C55E' },
      },
      fontFamily: {
        sans: ['Inter', 'Segoe UI', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'SFMono-Regular', 'Consolas', 'monospace'],
      },
      fontSize: {
        'heading-1': ['48px', '56px'],
        'heading-2': ['32px', '40px'],
        'heading-3': ['24px', '32px'],
        body: ['16px', '24px'],
        'body-sm': ['14px', '20px'],
        mono: ['14px', '20px'],
        caption: ['12px', '16px'],
      },
      spacing: { 1: '4px', 2: '8px', 3: '12px', 4: '16px', 6: '24px', 8: '32px', 12: '48px' },
      borderRadius: { small: '4px', medium: '8px', large: '12px', pill: '999px' },
      boxShadow: {
        card: '0 1px 2px rgba(0,0,0,0.30), 0 1px 3px rgba(0,0,0,0.20)',
        elevated: '0 8px 24px rgba(0,0,0,0.45), 0 2px 6px rgba(0,0,0,0.30)',
      },
      screens: { mobile: '375px', tablet: '768px', laptop: '1024px', desktop: '1440px' },
    },
  },
  plugins: [],
};
