import React, { useEffect, useRef } from 'react';
import Button from './Button';

/**
 * Modal — review dialog with Approve / Modify / Reject actions.
 * Traps focus, closes on Escape, labelled via aria-labelledby.
 */
export function Modal({ open, title, onClose, onApprove, onModify, onReject, children }) {
  const ref = useRef(null);
  useEffect(() => {
    if (open) ref.current?.focus();
    const onKey = (e) => e.key === 'Escape' && onClose?.();
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div role="presentation" onClick={onClose}
      style={{ position: 'fixed', inset: 0, background: 'rgba(4,10,20,0.7)', display: 'grid', placeItems: 'center', zIndex: 50, padding: 'var(--space-4)' }}>
      <div
        role="dialog" aria-modal="true" aria-labelledby="modal-title" ref={ref} tabIndex={-1}
        onClick={(e) => e.stopPropagation()}
        style={{ background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-large)', boxShadow: 'var(--shadow-elevated)', maxWidth: 560, width: '100%', padding: 'var(--space-6)' }}
      >
        <h2 id="modal-title" style={{ font: 'var(--text-heading-3)', color: 'var(--text-primary)', margin: '0 0 var(--space-4)' }}>{title}</h2>
        <div style={{ color: 'var(--text-body)', font: 'var(--text-body)' }}>{children}</div>
        <footer style={{ display: 'flex', gap: 'var(--space-3)', justifyContent: 'flex-end', marginTop: 'var(--space-6)', flexWrap: 'wrap' }}>
          <Button variant="ghost" onClick={onReject}>Reject</Button>
          <Button variant="secondary" onClick={onModify}>Modify</Button>
          <Button variant="primary" onClick={onApprove}>Approve</Button>
        </footer>
      </div>
    </div>
  );
}
export default Modal;
