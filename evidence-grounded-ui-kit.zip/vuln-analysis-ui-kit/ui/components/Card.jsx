import React, { useState } from 'react';

/**
 * Card — surface container. EvidenceCard adds a raw/normalized view toggle
 * and an inline citation list (used on Evidence Viewer and Gemini Analysis).
 */
export function Card({ title, actions, children, elevated = false, style }) {
  return (
    <section
      style={{
        background: 'var(--surface-card)', border: '1px solid var(--border-default)',
        borderRadius: 'var(--radius-large)', padding: 'var(--space-6)',
        boxShadow: elevated ? 'var(--shadow-elevated)' : 'var(--shadow-card)', ...style,
      }}
    >
      {(title || actions) && (
        <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-4)' }}>
          <h3 style={{ font: 'var(--text-heading-3)', color: 'var(--text-primary)', margin: 0 }}>{title}</h3>
          {actions}
        </header>
      )}
      {children}
    </section>
  );
}

export function EvidenceCard({ evidence }) {
  const [raw, setRaw] = useState(false);
  const fields = [
    ['Method', evidence.method], ['Path', evidence.path],
    ['Response code', evidence.responseCode], ['Image region', evidence.imageRegion],
    ['Code context', evidence.codeContext],
  ].filter(([, v]) => v);
  return (
    <Card
      title={evidence.title}
      actions={
        <button
          onClick={() => setRaw(!raw)}
          aria-pressed={raw}
          style={{ background: 'none', border: '1px solid var(--border-default)', color: 'var(--text-secondary)', borderRadius: 'var(--radius-small)', padding: '4px 10px', cursor: 'pointer', font: 'var(--text-caption)' }}
        >
          {raw ? 'Normalized view' : 'Raw view'}
        </button>
      }
    >
      {raw ? (
        <pre style={{ font: 'var(--text-mono)', color: 'var(--text-body)', background: 'var(--color-neutral-900)', padding: 'var(--space-4)', borderRadius: 'var(--radius-medium)', overflow: 'auto', maxHeight: 320 }}>
          {evidence.raw}
        </pre>
      ) : (
        <dl style={{ display: 'grid', gridTemplateColumns: '160px 1fr', gap: 'var(--space-2) var(--space-4)', margin: 0 }}>
          {fields.map(([k, v]) => (
            <React.Fragment key={k}>
              <dt style={{ font: 'var(--text-body-sm)', color: 'var(--text-secondary)' }}>{k}</dt>
              <dd style={{ font: 'var(--text-mono)', color: 'var(--text-body)', margin: 0, wordBreak: 'break-all' }}>{v}</dd>
            </React.Fragment>
          ))}
        </dl>
      )}
      {evidence.citations?.length > 0 && (
        <footer style={{ marginTop: 'var(--space-4)', borderTop: '1px solid var(--border-default)', paddingTop: 'var(--space-3)' }}>
          <p style={{ font: 'var(--text-caption)', color: 'var(--text-secondary)', margin: '0 0 var(--space-2)' }}>Cited evidence</p>
          <ul style={{ margin: 0, paddingLeft: 'var(--space-4)' }}>
            {evidence.citations.map((c, i) => (
              <li key={i} style={{ font: 'var(--text-body-sm)', color: 'var(--color-primary-100)' }}>
                <q>{c.snippet}</q> — {c.source}
              </li>
            ))}
          </ul>
        </footer>
      )}
    </Card>
  );
}
export default Card;
