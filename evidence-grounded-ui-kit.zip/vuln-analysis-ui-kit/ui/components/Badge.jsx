import React from 'react';

/** Severity badge — Critical/High/Medium/Low color mapping per tokens. */
const MAP = {
  Critical: 'var(--color-severity-critical)',
  High: 'var(--color-severity-high)',
  Medium: 'var(--color-severity-medium)',
  Low: 'var(--color-severity-low)',
};

export function Badge({ severity, label, color, title }) {
  const c = color || MAP[severity] || 'var(--color-info-500)';
  return (
    <span
      role="status"
      title={title}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        font: 'var(--text-caption)', fontWeight: 700, letterSpacing: '0.02em',
        color: 'var(--color-primary-900)', background: c,
        borderRadius: 'var(--radius-pill)', padding: '2px 10px', whiteSpace: 'nowrap',
      }}
    >
      {label || severity}
    </span>
  );
}
export default Badge;
