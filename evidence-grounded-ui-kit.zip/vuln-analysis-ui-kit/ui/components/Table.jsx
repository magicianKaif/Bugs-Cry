import React, { useState } from 'react';
import Badge from './Badge';

/**
 * Table — sortable data table with row actions and inline severity badges.
 * Keyboard: header buttons are native <button> inside <th scope="col">.
 */
export function Table({ columns, rows, onRowAction, caption }) {
  const [sort, setSort] = useState({ key: null, dir: 1 });
  const sorted = [...rows].sort((a, b) => {
    if (!sort.key) return 0;
    const av = a[sort.key], bv = b[sort.key];
    return (typeof av === 'number' ? av - bv : String(av).localeCompare(String(bv))) * sort.dir;
  });
  return (
    <div style={{ overflowX: 'auto', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-large)' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', font: 'var(--text-body-sm)' }}>
        {caption && <caption style={{ textAlign: 'left', padding: 'var(--space-3)', color: 'var(--text-secondary)', background: 'var(--surface-card)' }}>{caption}</caption>}
        <thead>
          <tr style={{ background: 'var(--surface-raised)' }}>
            {columns.map((c) => (
              <th key={c.key} scope="col" style={{ textAlign: 'left', padding: 'var(--space-3) var(--space-4)', color: 'var(--text-secondary)', font: 'var(--text-caption)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                {c.sortable ? (
                  <button
                    onClick={() => setSort({ key: c.key, dir: sort.key === c.key ? -sort.dir : 1 })}
                    style={{ all: 'unset', cursor: 'pointer', color: 'inherit' }}
                    aria-sort={sort.key === c.key ? (sort.dir === 1 ? 'ascending' : 'descending') : undefined}
                  >
                    {c.label} {sort.key === c.key ? (sort.dir === 1 ? '▲' : '▼') : '↕'}
                  </button>
                ) : c.label}
              </th>
            ))}
            {onRowAction && <th scope="col" style={{ padding: 'var(--space-3) var(--space-4)' }}><span className="visually-hidden">Actions</span></th>}
          </tr>
        </thead>
        <tbody>
          {sorted.map((row) => (
            <tr key={row.id} style={{ borderTop: '1px solid var(--border-default)', background: 'var(--surface-card)' }}>
              {columns.map((c) => (
                <td key={c.key} style={{ padding: 'var(--space-3) var(--space-4)', color: 'var(--text-body)' }}>
                  {c.key === 'severity' ? <Badge severity={row.severity} /> : row[c.key]}
                </td>
              ))}
              {onRowAction && (
                <td style={{ padding: 'var(--space-3) var(--space-4)', textAlign: 'right' }}>
                  <button onClick={() => onRowAction(row)} style={{ background: 'none', border: 'none', color: 'var(--color-primary-100)', cursor: 'pointer', font: 'var(--text-body-sm)' }}>
                    Review
                  </button>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
export default Table;
