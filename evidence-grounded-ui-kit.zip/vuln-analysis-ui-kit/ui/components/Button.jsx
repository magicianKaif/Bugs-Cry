import React from 'react';
import '../styles/tokens.css';

/**
 * Button — primary action component.
 * variants: primary (accent orange), secondary (teal outline), ghost, icon
 * All variants: min 40px hit area, visible focus ring via tokens.css :focus-visible.
 */
export function Button({ variant = 'primary', size = 'md', icon, children, style, ...rest }) {
  const base = {
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 'var(--space-2)',
    font: 'var(--text-body-sm)', fontWeight: 600, border: '1px solid transparent',
    borderRadius: 'var(--radius-medium)', cursor: 'pointer', minHeight: size === 'sm' ? 32 : 40,
    padding: size === 'sm' ? '0 var(--space-3)' : variant === 'icon' ? 0 : '0 var(--space-4)',
    width: variant === 'icon' ? (size === 'sm' ? 32 : 40) : undefined,
    transition: `background var(--motion-fast) var(--motion-ease)`,
  };
  const variants = {
    primary:   { background: 'var(--color-accent-500)', color: 'var(--text-on-accent)' },
    secondary: { background: 'transparent', color: 'var(--color-teal-500)', borderColor: 'var(--color-teal-500)' },
    ghost:     { background: 'transparent', color: 'var(--text-body)' },
    icon:      { background: 'transparent', color: 'var(--text-secondary)' },
    danger:    { background: 'var(--color-danger-500)', color: 'var(--color-neutral-0)' },
  };
  return (
    <button style={{ ...base, ...variants[variant], ...style }} {...rest}>
      {icon}{children}
    </button>
  );
}
export default Button;
