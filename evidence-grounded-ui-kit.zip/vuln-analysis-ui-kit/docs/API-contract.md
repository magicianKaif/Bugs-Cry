# API Contract — Orchestration Service

Base URL: `https://api.example.internal/v1` · Auth: `Authorization: Bearer <session-token>`
API keys for Gemini/OpenAI/Anthropic live in server-side environment variables
(`GEMINI_API_KEY`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`) — never sent from the client.

## POST /upload
Submit raw evidence. `multipart/form-data` for images, JSON for text.
```json
{ "type": "image|http|code", "content": "<string | file-ref>", "redact": true }
```
→ `201 { "evidenceId": "EV-0042" }`

## POST /extract
Normalize evidence into a structured object.
```json
{ "evidenceId": "EV-0042" }
```
→ `200 { "evidence": { "method": "POST", "headers": {}, "params": {}, "responseCode": 200, "codeContext": "...", "imageRegion": "...", "raw": "..." } }`

## POST /analyze/gemini
Analyst stage: validity, classification, severity.
```json
{ "evidenceId": "EV-0042" }
```
→ `200 { "verdict": "true_positive|false_positive|uncertain|informational", "confidence": 91, "cwe": "CWE-862", "owasp": "A01:2021", "cvss": "CVSS:3.1/...", "cvssJustification": "...", "citations": [{ "snippet": "...", "source": "..." }] }`

## POST /translate/chatgpt
Translator stage: dual-audience output.
```json
{ "evidenceId": "EV-0042", "analysisId": "AN-110" }
```
→ `200 { "executiveSummary": "...", "businessRisk": "...", "priority": "...", "remediationSteps": ["..."], "codeExample": "..." }`

## POST /synthesize/claude
Synthesizer stage: report assembly + coherence checks.
```json
{ "findingIds": ["FND-001", "FND-002"] }
```
→ `200 { "structure": [{ "section": "...", "detail": "..." }], "contradictions": [{ "field": "...", "description": "...", "analyst": "...", "translator": "..." }] }`

## POST /review
Submit human review decisions for flagged findings (confidence < 70 or cross-model disagreement).
```json
{ "findingId": "FND-007", "decision": "approve|modify|reject", "modifications": { "severity": "High" }, "reviewerNote": "..." }
```
→ `200 { "findingId": "FND-007", "status": "approved" }`

## POST /report/export
Generate the final DOCX.
```json
{ "findingIds": ["FND-001"], "template": "default", "tracks": ["executive", "developer"] }
```
→ `200 { "downloadUrl": "https://…/report.docx", "expiresIn": 3600 }`

## Error shape (all endpoints)
```json
{ "error": { "code": "UPSTREAM_MODEL_TIMEOUT", "message": "...", "retryable": true } }
```
