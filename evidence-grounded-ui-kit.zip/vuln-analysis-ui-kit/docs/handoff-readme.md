# Developer Handoff Notes

## Component inventory

| Component | File | Props (key ones) | Tokens used |
|---|---|---|---|
| `Button` | ui/components/Button.jsx | `variant: primary|secondary|ghost|icon|danger`, `size: sm|md` | `--color-accent-500`, `--radius-medium` |
| `Badge` | ui/components/Badge.jsx | `severity: Critical|High|Medium|Low`, `label`, `color` | `--color-severity-*` |
| `Card` / `EvidenceCard` | ui/components/Card.jsx | `title`, `actions`, `elevated`; EvidenceCard takes an `evidence` object | `--surface-card`, `--shadow-card` |
| `Table` | ui/components/Table.jsx | `columns[{key,label,sortable}]`, `rows`, `onRowAction` | `--surface-raised` |
| `Modal` | ui/components/Modal.jsx | `open`, `onApprove/onModify/onReject` | `--shadow-elevated` |
| `ConfidenceMeter` | ui/screens/GeminiAnalysis.jsx | `value: 0–100` | threshold 70 |

## Token usage examples

```css
/* CSS variables */
.banner { background: var(--color-primary-900); color: var(--text-body); }
.cta    { background: var(--color-accent-500); color: var(--text-on-accent); border-radius: var(--radius-medium); }
```

```jsx
// React inline (as used in the stubs)
<Button variant="primary" onClick={save}>Save settings</Button>
<Badge severity={finding.severity} />
<ConfidenceMeter value={finding.confidence} />
```

```js
// JSON tokens (design/design-system.tokens.json)
import tokens from '../design/design-system.tokens.json';
const danger = tokens.color['danger-500'].value;
```

## UI microcopy

- Upload hint (HTTP): "Paste the raw request and response pair, e.g. from Burp Suite or OWASP ZAP."
- Upload hint (code): "Paste the flagged code with at least 5 lines of surrounding context."
- Confidence tooltip: "How sure the Analyst model is, based on evidence strength. Below 70%, a human must review."
- CWE tooltip: "Common Weakness Enumeration — a community catalog of software weakness types."
- CVSS tooltip: "Common Vulnerability Scoring System — industry standard for rating severity (0.0–10.0)."
- Reviewer guidance: "Check the cited evidence first; if the raw input does not support the claim, reject."
- Privacy notice: "Evidence is sent to third-party APIs (Google Gemini, OpenAI, Anthropic). Do not upload data covered by disclosure restrictions."

## Accessibility checklist

- Body text pairs verified ≥ 4.5:1 on their intended surfaces (`--text-body` on `--surface-app` ≈ 13.9:1).
- Focus ring via global `:focus-visible` rule in tokens.css — do not remove.
- All interactive elements are native `<button>`/`<input>`/`<select>`; table headers expose `aria-sort`.
- `prefers-reduced-motion` disables transitions globally.

## Responsive breakpoints

1440px (desktop) · 1024px (laptop) · 768px (tablet) · 375px (mobile).
Screens use `repeat(auto-fit, minmax(...))` grids — they reflow without breakpoint-specific code.

## Canva assets

| Asset | File | Canva edit link |
|---|---|---|
| Hero banner | design/canva-assets/hero-banner.png (+@2x, .pdf) | https://www.canva.com/d/AkbO6RLSqBtilOA |
| Pipeline diagram (hand-authored SVG, authoritative) | design/canva-assets/pipeline-diagram.svg (+png, @2x) | — |
| Pipeline concept (Canva draft) | design/canva-assets/canva-pipeline-concept.pdf | https://www.canva.com/d/uRYAnq5Rh8Xdj1L |
| Report cover | design/canva-assets/report-cover.pdf/.png | https://www.canva.com/d/ostSTEX5avLhOyK |
| 6 line icons | design/canva-assets/icons/*.svg | hand-authored, stroke=currentColor |

Note: Canva PNG/JPG export was unavailable for two designs at generation time (platform permission error); PDF exports are included and the PNGs were rendered from them.
