# Evidence-Grounded Vulnerability Analysis — UI Kit

Prototype file set for the web application implementing the framework from
*An Evidence-Grounded Multi-Agent LLM Framework for Vulnerability Analysis and Security Report Generation*:
Upload → Extract → **Gemini (Analyst)** → **ChatGPT (Translator)** → **Claude (Synthesizer)** → Human Review → DOCX Export.

## Contents

```
design/
  design-system.tokens.json   # colors, type, spacing, radius, shadow, breakpoints (W3C token format)
  canva-assets/               # hero banner, pipeline diagram, 6 SVG icons, report cover
ui/
  screens/                    # 8 screens (React, JSX)
  components/                 # Button, Badge, Card, Table, Modal
  styles/tokens.css           # CSS variables + focus/ reduced-motion rules
  styles/tailwind.config.js   # optional Tailwind mapping of the same tokens
  fixtures/findings.json      # 10 sample findings (mixed verdicts, severities, flags)
docs/
  DOCX-template.docx          # report template with {{placeholders}}
  API-contract.md             # /upload /extract /analyze/gemini /translate/chatgpt /synthesize/claude /review /report/export
  handoff-readme.md           # component props, token keys, microcopy, a11y notes
```

## Quick start (React stubs)

```bash
npm create vite@latest my-app -- --template react
cp -r ui/ my-app/src/ui/
# import tokens.css once in your entry file:
#   import './ui/styles/tokens.css';
```

The screens are presentation-layer stubs with realistic demo data; wire them to the
orchestration endpoints in `docs/API-contract.md`.

## Design constraints honored

- Muted dark blues + slate grays, orange (`#F97316`) / teal (`#14B8A6`) accents
- WCAG AA: body-text pairs ≥ 4.5:1; visible `:focus-visible` ring; semantic HTML
- Breakpoints: 1440 / 1024 / 768 / 375 (auto-fit grids reflow without media queries)
- Human Review Gate surfaces all findings with confidence < 70 or cross-model disagreement
